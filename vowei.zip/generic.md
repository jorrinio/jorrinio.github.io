---
layout: post
title: Ventajas 
description: 
image: 
nav-menu: true
---
<!-- Main -->
<div id="main" class="alt">

<!-- One -->
<section id="one">

<!-- Content -->
<h2 id="content">Facilidades</h2>
<p></p>
<div class="6u 12u$(small)">
    <h3><span class="icon fa-calculator"></span>Presupuesto sin Compromiso</h3>
    <p></p>
</div>
<div class="6u$ 12u$(small)">
    <h3><span class="icon alt fa-commenting"></span>Consulta gratuita</h3>
    <p></p>
</div>


</section>
<!--
<section id="two">
<h2 id="content">Facilidades</h2>
<p></p>
<div class="6u 12u$(small)">
    <h3><span class="icon fa-calculator"></span> Presupuesto sin Compromiso</h3>
    <p></p>
</div>
<div class="6u$ 12u$(small)">
    <h3><span class="icon alt fa-commenting"></span> Consulta gratuita</h3>
    <p></p>
</div>
</section>
-->
</div>

